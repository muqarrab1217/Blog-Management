export interface Blog {
  id: string;
  title: string;
  content: string;
  authorId: string;
  authorName: string;
  createdAt: Date;
  status: 'draft' | 'published' | 'pending' | 'approved' | 'rejected';
}

// Mock blogs for demonstration
let mockBlogs: Blog[] = [
  {
    id: '1',
    title: 'Getting Started with React',
    content: 'This is a comprehensive guide to getting started with React...',
    authorId: '2',
    authorName: 'John Doe',
    createdAt: new Date('2024-01-15'),
    status: 'approved'
  },
  {
    id: '2',
    title: 'Advanced TypeScript Tips',
    content: 'Here are some advanced TypeScript techniques that will improve your code...',
    authorId: '2',
    authorName: 'John Doe',
    createdAt: new Date('2024-01-10'),
    status: 'pending'
  }
];

class BlogService {
  async getBlogsByAuthor(authorId: string): Promise<Blog[]> {
    await new Promise(resolve => setTimeout(resolve, 500));
    return mockBlogs.filter(blog => blog.authorId === authorId);
  }

  async getAllBlogs(): Promise<Blog[]> {
    await new Promise(resolve => setTimeout(resolve, 500));
    return mockBlogs;
  }

  async createBlog(blog: Omit<Blog, 'id' | 'createdAt'>): Promise<Blog> {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const newBlog: Blog = {
      ...blog,
      id: Date.now().toString(),
      createdAt: new Date()
    };

    mockBlogs.unshift(newBlog);
    return newBlog;
  }

  async updateBlog(id: string, updates: Partial<Blog>): Promise<Blog> {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const blogIndex = mockBlogs.findIndex(blog => blog.id === id);
    if (blogIndex === -1) {
      throw new Error('Blog not found');
    }

    mockBlogs[blogIndex] = { ...mockBlogs[blogIndex], ...updates };
    return mockBlogs[blogIndex];
  }

  async deleteBlog(id: string): Promise<void> {
    await new Promise(resolve => setTimeout(resolve, 500));
    mockBlogs = mockBlogs.filter(blog => blog.id !== id);
  }

  async updateBlogStatus(id: string, status: Blog['status']): Promise<Blog> {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const blogIndex = mockBlogs.findIndex(blog => blog.id === id);
    if (blogIndex === -1) {
      throw new Error('Blog not found');
    }

    mockBlogs[blogIndex].status = status;
    return mockBlogs[blogIndex];
  }
}

export const blogService = new BlogService();