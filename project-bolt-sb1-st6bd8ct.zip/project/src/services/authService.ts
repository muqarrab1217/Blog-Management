export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'customer';
  subscriptionPlan?: 'Basic' | 'Premium' | 'Enterprise';
}

// Mock users for demonstration
const mockUsers: (User & { password: string })[] = [
  {
    id: '1',
    name: 'Admin User',
    email: 'admin@example.com',
    password: 'admin123',
    role: 'admin'
  },
  {
    id: '2',
    name: 'John Doe',
    email: 'john@example.com',
    password: 'customer123',
    role: 'customer',
    subscriptionPlan: 'Premium'
  }
];

class AuthService {
  async login(email: string, password: string, role: 'admin' | 'customer'): Promise<User> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    const user = mockUsers.find(u => u.email === email && u.password === password && u.role === role);
    
    if (!user) {
      throw new Error('Invalid credentials');
    }

    const token = `mock-jwt-token-${user.id}`;
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify({ ...user, password: undefined }));

    return { ...user, password: undefined } as User;
  }

  async signup(name: string, email: string, password: string): Promise<User> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Check if user already exists
    const existingUser = mockUsers.find(u => u.email === email);
    if (existingUser) {
      throw new Error('User already exists');
    }

    const newUser: User = {
      id: Date.now().toString(),
      name,
      email,
      role: 'customer',
      subscriptionPlan: 'Basic'
    };

    mockUsers.push({ ...newUser, password });

    const token = `mock-jwt-token-${newUser.id}`;
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(newUser));

    return newUser;
  }

  getCurrentUser(): User | null {
    const userStr = localStorage.getItem('user');
    return userStr ? JSON.parse(userStr) : null;
  }

  logout(): void {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  }
}

export const authService = new AuthService();