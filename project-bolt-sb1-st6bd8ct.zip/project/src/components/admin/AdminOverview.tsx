import React from 'react';
import { Users, FileText, CheckCircle, Clock } from 'lucide-react';
import { useActivity } from '../../contexts/ActivityContext';
import StatusBadge from '../StatusBadge';

function AdminOverview() {
  const { customers } = useActivity();

  const onlineCustomers = customers.filter(c => c.isOnline);
  const offlineCustomers = customers.filter(c => !c.isOnline);

  const stats = [
    {
      name: 'Total Customers',
      value: customers.length,
      icon: Users,
      color: 'bg-blue-500'
    },
    {
      name: 'Online Now',
      value: onlineCustomers.length,
      icon: Users,
      color: 'bg-green-500'
    },
    {
      name: 'Pending Blogs',
      value: 3,
      icon: FileText,
      color: 'bg-yellow-500'
    },
    {
      name: 'Approved Today',
      value: 5,
      icon: CheckCircle,
      color: 'bg-indigo-500'
    }
  ];

  return (
    <div className="px-4 sm:px-6 lg:px-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
        <p className="mt-2 text-gray-600">Monitor customer activity and manage platform operations.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 mb-8">
        {stats.map((item) => {
          const Icon = item.icon;
          return (
            <div key={item.name} className="bg-white overflow-hidden shadow rounded-lg">
              <div className="p-5">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className={`${item.color} p-3 rounded-md`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">{item.name}</dt>
                      <dd className="text-lg font-medium text-gray-900">{item.value}</dd>
                    </dl>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Online Customers */}
        <div className="bg-white shadow rounded-lg">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-medium text-gray-900">Currently Online</h3>
          </div>
          <div className="px-6 py-4">
            {onlineCustomers.length > 0 ? (
              <div className="space-y-4">
                {onlineCustomers.map((customer) => (
                  <div key={customer.id} className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="flex-shrink-0">
                        <div className="w-8 h-8 bg-indigo-600 rounded-full flex items-center justify-center">
                          <span className="text-sm font-medium text-white">
                            {customer.name.charAt(0).toUpperCase()}
                          </span>
                        </div>
                      </div>
                      <div className="ml-4">
                        <p className="text-sm font-medium text-gray-900">{customer.name}</p>
                        <p className="text-sm text-gray-500">{customer.email}</p>
                      </div>
                    </div>
                    <StatusBadge isOnline={customer.isOnline} size="sm" />
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500 text-sm">No customers currently online</p>
            )}
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white shadow rounded-lg">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-medium text-gray-900">Recent Activity</h3>
          </div>
          <div className="px-6 py-4">
            <div className="space-y-4">
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <Clock className="w-5 h-5 text-gray-400" />
                </div>
                <div className="ml-3">
                  <p className="text-sm text-gray-900">New blog submitted by John Doe</p>
                  <p className="text-xs text-gray-500">2 minutes ago</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <Users className="w-5 h-5 text-gray-400" />
                </div>
                <div className="ml-3">
                  <p className="text-sm text-gray-900">Jane Smith came online</p>
                  <p className="text-xs text-gray-500">5 minutes ago</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <CheckCircle className="w-5 h-5 text-gray-400" />
                </div>
                <div className="ml-3">
                  <p className="text-sm text-gray-900">Blog approved and published</p>
                  <p className="text-xs text-gray-500">10 minutes ago</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AdminOverview;