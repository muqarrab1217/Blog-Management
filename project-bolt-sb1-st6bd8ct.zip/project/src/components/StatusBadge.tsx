import React from 'react';
import { Circle } from 'lucide-react';

interface StatusBadgeProps {
  isOnline: boolean;
  size?: 'sm' | 'md' | 'lg';
}

function StatusBadge({ isOnline, size = 'md' }: StatusBadgeProps) {
  const sizeClasses = {
    sm: 'w-2 h-2',
    md: 'w-3 h-3',
    lg: 'w-4 h-4'
  };

  return (
    <div className="flex items-center gap-2">
      <Circle
        className={`${sizeClasses[size]} ${isOnline ? 'fill-green-500 text-green-500' : 'fill-gray-400 text-gray-400'}`}
      />
      <span className={`text-sm font-medium ${isOnline ? 'text-green-600' : 'text-gray-500'}`}>
        {isOnline ? 'Online' : 'Offline'}
      </span>
    </div>
  );
}

export default StatusBadge;